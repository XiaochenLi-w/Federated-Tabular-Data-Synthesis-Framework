"""Synthesizers module."""


from .train_wrapper import train_wrapper_tab_ddpm