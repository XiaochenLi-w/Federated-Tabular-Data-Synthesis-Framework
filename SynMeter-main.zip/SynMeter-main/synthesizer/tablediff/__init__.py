

from .train_wrapper import train_wrapper_tablediffusion
