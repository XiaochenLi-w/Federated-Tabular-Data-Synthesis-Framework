Put the dataset to here with the following structure:

```
- datasets/
    - adult/
        - adult.csv  # the raw dataset
        - adult.json # the metadata of the dataset
        - train.csv
        - val.csv
        - test.csv
```